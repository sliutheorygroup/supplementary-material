How to use these files:
Directory all_structures includes all the structures optimized by PBE.
Directory all_structures/HPs and all_structures/VODPs include all the compouds containing I. 
Analogues containing Br and Cl can be easily obtained through simple modification.
Directory all_structures/BDHPs include structures of CsTlCl3, CsTlF3 and CsAuCl3.

Directory DFT+U_example and DFT+U+V_example include an example about how to calculate the band gap of alpha_CsSnI3 using DFT+U(+V) method.

